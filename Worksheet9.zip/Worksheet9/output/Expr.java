public abstract class Expr {
    public abstract int eval();
}