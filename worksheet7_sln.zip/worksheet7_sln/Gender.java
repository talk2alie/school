public enum Gender {
    Female,
    Male,
    Trans,
    Other
}