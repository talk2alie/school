public enum MaritalStatus {
    Divorced,
    Married,
    Separated,
    Single
}